package OShw2;
import java.util.Scanner;

public class Fibonacci {
    
    public static void fib(int n) {
        int[] arr = new int[n];
        arr[0] = 0;
        arr[1] = 1;
        if (n == 1) {
            System.out.println("element " + arr[0] + " is generated and stored in array");
        } else if (n == 2) {
            System.out.println("element " + arr[0] + " is generated and stored in array");
            System.out.println("element " + arr[1] + " is generated and stored in array");
        } else {
            System.out.println("element " + arr[0] + " is generated and stored in array");
            System.out.println("element " + arr[1] + " is generated and stored in array");
            for (int i = 2; i < n; i++) {
                int ele = arr[i-1] + arr[i-2];
                arr[i] = arr[i-1] + arr[i-2];
                System.out.println("element " + ele + " is generated and stored in array");
            }
            System.out.println("The resultant fibonacci series is");
            for (int i = 0; i < n; i++) {
            	System.out.print(arr[i] + " ");
            }
            System.out.println();
        }
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number to print fibonacci:");
        int n = sc.nextInt();
        sc.close();
        long starttime = System.nanoTime();
        Thread t1 = new Thread(() -> fib(n));
        t1.start();
        try {
            t1.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        long stoptime = System.nanoTime();
        double duration = (stoptime - starttime) / 1_000_000_000.0;
        System.out.println("Time taken in execution in sec: " + duration);
    }
}