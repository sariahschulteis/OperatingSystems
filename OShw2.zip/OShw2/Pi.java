package OShw2;
import java.util.Random;

public class Pi {

    static int numPoints = 1000000;
    static int pointsInCircle = 0;
    static Object lock = new Object();
    
    public static void main(String[] args) {
        int numThreads = 4;
        
        Thread[] threads = new Thread[numThreads];
        
        for (int i = 0; i < numThreads; i++) {
            threads[i] = new Thread(new PointGenerator());
            threads[i].start();
        }
        
        for (int i = 0; i < numThreads; i++) {
            try {threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        double pi = 4.0 * pointsInCircle / numPoints;
        
        System.out.println("Estimate of pi = " + pi);
    }
    
    static class PointGenerator implements Runnable {
        public void run() {
            Random r = new Random();
            int localPointsInCircle = 0;
            
            for (int i = 0; i < numPoints; i++) {
                double x = r.nextDouble();
                double y = r.nextDouble();
                
                if (x*x + y*y <= 1.0) {
                    localPointsInCircle++;
                }
            }
            
            synchronized (lock) {
                pointsInCircle += localPointsInCircle;
            }
        }
    }
}



